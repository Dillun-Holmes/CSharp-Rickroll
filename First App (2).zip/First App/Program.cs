﻿using System;
using System.Diagnostics;
using System.Threading;

namespace FleetManagementApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Fleet Management App");
            Console.WriteLine("================================");

            // Display fleet management options
            DisplayFleetManagementOptions();

            // Wait for user input
            Console.ReadLine();
        }

        static void DisplayFleetManagementOptions()
        {
            Console.WriteLine("1. View Fleet Status");
            Console.WriteLine("2. Track Vehicles");
            Console.WriteLine("3. Schedule Maintenance");
            Console.WriteLine("4. Play Fleet Management Tutorial");
            Console.WriteLine("5. Exit");

            // Get user choice
            Console.Write("Enter your choice (1-5): ");
            string choice = Console.ReadLine();

            // Process user choice
            switch (choice)
            {
                case "1":
                case "3":
                    PlayTutorial("Fleet Management Tutorial", "https://www.youtube.com/watch?v=o-YBDTqX_ZU");
                    break;
                case "2":
                case "4":
                    DisplayRickrollImage();
                    break;
                case "5":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                    DisplayFleetManagementOptions();
                    break;
            }
        }

        static void DisplayRickrollImage()
        {
            // Display Rickroll image in an HTML document
            string htmlContent = $"<html><body><img src='https://media-cldnry.s-nbcnews.com/image/upload/t_fit-760w,f_auto,q_auto:best/streams/2012/May/120523/383994-rickroll.jpg' alt='Rickroll Image'></body></html>";

            // Save the HTML content to a temporary file
            string tempHtmlPath = System.IO.Path.GetTempFileName() + ".html";
            System.IO.File.WriteAllText(tempHtmlPath, htmlContent);

            // Open the HTML document in the default browser
            OpenUrlInDefaultBrowser(tempHtmlPath);

            // Return to the main menu
            DisplayFleetManagementOptions();
        }

        static void PlayTutorial(string option, string youtubeLink)
        {
            Console.WriteLine($"Playing {option}...");

            // Open the YouTube link using the default browser
            OpenUrlInDefaultBrowser(youtubeLink);

            // Wait for the video to play (you can adjust the duration)
            Thread.Sleep(10000);

            // Return to the main menu
            DisplayFleetManagementOptions();
        }

        static void OpenUrlInDefaultBrowser(string url)
        {
            try
            {
                // Use the ProcessStartInfo class to start the default browser with the URL
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                };

                Process.Start(psi);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error opening URL: {ex.Message}");
            }
        }
    }
}




